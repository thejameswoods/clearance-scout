repo: thejameswoods/clearance-scout
branch: main

## Last sync

date: 2026-09-01T15:55:45Z

### Updated in this project

- Recreated the current Deals tab (filters, deal table, product-detail modal) from the live frontend.
- Copied the dashboard stylesheet verbatim as the recreation's baseline.
- Added four wireframe directions for a multi-store, tree-department Deals page.

## Screen map

| Screen | Built from |
| --- | --- |
| Deals — Current UI.dc.html | web/frontend/index.html, web/frontend/app.js, web/frontend/style.css |
| Deals Wireframes.dc.html | db/init/001_schema.sql, web/frontend/app.js, README.md |
| web/frontend/style.css (copied) | web/frontend/style.css |
